# authentication/admin.py
from django.contrib import admin
from authentication.models import MyUser, Company
from authentication.forms import MyUserCreationForm


class AppointedCompanyInline(admin.TabularInline):
    """Shows the companies appointed under a super company, editable inline."""
    model = Company
    fk_name = 'parent_company'
    fields = ('name', 'is_super_company')
    readonly_fields = ('name',)
    extra = 0
    verbose_name = 'Appointed Company'
    verbose_name_plural = 'Appointed Companies'
    can_delete = False

    def has_add_permission(self, _request, _obj=None):
        return False


@admin.register(Company)
class CompanyAdmin(admin.ModelAdmin):
    list_display = ('id', 'name', 'is_super_company', 'parent_company')
    list_filter = ('is_super_company',)
    search_fields = ('name',)
    fields = (
        'name', 'name_ar', 'logo', 'icon',
        'is_super_company', 'parent_company',
        # Permissions
        'is_temperature', 'is_guard', 'is_peoplecount', 'is_kitchen',
        'is_aggf', 'is_smoking', 'is_face_detection', 'is_falldetection',
        'is_violencedetection', 'is_crowdmonitoring', 'is_climbmonitoring',
        'is_abnormalactivity', 'is_livestream', 'is_foodweight', 'is_cleanness',
        'is_buffet', 'is_cleaners', 'is_sentiment', 'is_water_tank',
        'is_sensor_assign', 'is_annotator_ranking', 'is_settings',
    )
    inlines = [AppointedCompanyInline]

    def get_queryset(self, request):
        return super().get_queryset(request).select_related('parent_company')


@admin.register(MyUser)
class MyUserAdmin(admin.ModelAdmin):
    add_form = MyUserCreationForm
    list_display = ('email', 'username', 'is_admin', 'company')
    search_fields = ('email', 'username')
    readonly_fields = ('date_joined', 'last_login')

    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': (
                'email', 'username', 'company', 'password1', 'password2',
                'is_admin', 'is_active', 'is_staff', 'is_superuser', 'is_annotator',
                'company_annotator', 'camera_type_annotator', 'sensor_update_permission',
                'assigned_tent',
                'is_temperature', 'is_guard', 'is_peoplecount', 'is_kitchen',
                'is_aggf', 'is_smoking', 'is_face_detection', 'is_falldetection',
                'is_violencedetection', 'is_crowdmonitoring', 'is_climbmonitoring',
                'is_abnormalactivity', 'is_foodweight', 'is_cleanness', 'is_livestream',
                'is_buffet', 'is_cleaners', 'is_sentiment', 'is_water_tank',
                'is_sensor_assign', 'is_annotator_ranking',
            ),
        }),
    )

    fieldsets = (
        (None, {
            'fields': ('email', 'username', 'company')
        }),
        ('Permissions', {
            'fields': (
                'is_admin', 'is_active', 'is_staff', 'is_superuser', 'is_annotator',
                'sensor_update_permission',
                'is_temperature', 'is_guard', 'is_peoplecount', 'is_kitchen',
                'is_aggf', 'is_smoking', 'is_face_detection', 'is_falldetection',
                'is_violencedetection', 'is_crowdmonitoring', 'is_climbmonitoring',
                'is_abnormalactivity', 'is_foodweight', 'is_cleanness', 'is_buffet',
                'is_cleaners', 'is_sentiment', 'is_water_tank', 'is_sensor_assign',
                'is_annotator_ranking', 'is_livestream',
            )
        }),
        ('Associations', {
            'fields': ('company_annotator', 'camera_type_annotator', 'assigned_tent')
        }),
        ('Important dates', {
            'fields': ('date_joined', 'last_login')
        }),
    )

    def get_fieldsets(self, request, obj=None):
        if not obj:
            return self.add_fieldsets
        return self.fieldsets

    def get_form(self, request, obj=None, **kwargs):
        if obj is None:
            kwargs['form'] = self.add_form
        return super().get_form(request, obj, **kwargs)
