from tent.models import Tent


def is_super_admin(user):
    """True when the user is an admin of a super company."""
    return (
        user.is_authenticated
        and user.is_admin
        and user.company_id is not None
        and user.company.is_super_company
    )


def get_appointed_companies(user):
    """
    Returns the queryset of companies a super-admin is allowed to manage.
    For a Django superuser this is all companies.
    For a super-company admin it is only the companies appointed to their super company.
    """
    from authentication.models import Company
    if user.is_superuser:
        return Company.objects.all()
    if is_super_admin(user):
        return user.company.appointed_companies.all()
    return None  # not applicable for regular admins / staff


def get_accessible_tents(user, company_id=None):
    """
    Returns a Tent queryset scoped to what the user is allowed to see.

    Django superuser        → all tents (optionally filtered by company_id)
    Super-company admin     → tents from appointed companies only
    Regular admin           → all tents within their own company
    Staff                   → only their assigned tents within their company
    """
    if user.is_superuser:
        qs = Tent.objects.all()
        if company_id:
            qs = qs.filter(company_id=company_id)
        return qs

    if is_super_admin(user):
        if company_id:
            return Tent.objects.filter(company_id=company_id)
        return Tent.objects.filter(company=user.company)

    if user.is_admin:
        return Tent.objects.filter(company=user.company)

    assigned_ids = user.assigned_tent.values_list('id', flat=True)
    return Tent.objects.filter(id__in=assigned_ids, company=user.company)
