from django.core.exceptions import FieldError
from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator

from rest_framework.generics import GenericAPIView
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response
from rest_framework import status
from rest_framework.views import APIView

from authentication.models import MyUser, Company
from authentication.serializers import (
    UserLoginSerializer, UserRegistrationSerializer, MyUserSerializer,
    PermissionListSerializer, CompanySerializer, UserPermissionListSerializer,
)
from authentication.utils import get_token_for_user, standard_response
from utils.access import is_super_admin

from tent.utils import CustomPagination
from utils.time import Current_saudi_time


class CompanyListView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, *args, **kwargs):
        try:
            if is_super_admin(request.user) or request.user.is_superuser:
                company = Company.objects.only('name', 'logo').all()
            else:
                company = Company.objects.only('name', 'logo').filter(
                    id=request.user.company_id)
        except Company.DoesNotExist:
            return Response({
                'success': False,
                'message': 'Company not found.',
                'data': None
            }, status=status.HTTP_404_NOT_FOUND)

        return Response({
            'success': True,
            'message': 'Company retrieved successfully.',
            'results': CompanySerializer(company, many=True).data
        }, status=status.HTTP_200_OK)


class CompanyWithLogo(APIView):
    """Retrieve a company's name and logo by company name or authenticated user."""

    def get(self, request, *args, **kwargs):
        name = request.query_params.get('name')
        company = None

        if name:
            try:
                company = Company.objects.only('name', 'logo', 'icon').get(name=name)
            except Company.DoesNotExist:
                return Response({
                    'success': False,
                    'message': 'Company not found.',
                    'data': None
                }, status=status.HTTP_404_NOT_FOUND)

        elif request.user and request.user.is_authenticated:
            if request.user.company:
                company = Company.objects.only('name', 'logo', 'icon').filter(
                    id=request.user.company_id).first()
            else:
                return Response({
                    'success': False,
                    'message': 'Authenticated user has no associated company.',
                    'data': None
                }, status=status.HTTP_400_BAD_REQUEST)

        else:
            return Response({
                'success': False,
                'message': 'Provide a company name or authenticate the user.',
                'data': None
            }, status=status.HTTP_400_BAD_REQUEST)

        return Response({
            'success': True,
            'message': 'Company retrieved successfully.',
            'data': CompanySerializer(company, context={'request': request}).data
        }, status=status.HTTP_200_OK)


class PermissionList(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, *args, **kwargs):
        user = request.user
        company = user.company

        if not company:
            return Response({
                "success": False,
                "message": "User is not assigned to any company.",
                "data": None
            }, status=status.HTTP_400_BAD_REQUEST)

        if user.is_admin:
            serializer = PermissionListSerializer(company)
        elif user.is_staff:
            serializer = UserPermissionListSerializer(user)
        else:
            return Response({
                "success": False,
                "message": "Permission denied.",
                "data": None
            }, status=status.HTTP_403_FORBIDDEN)

        return Response({
            "success": True,
            "message": "Permissions retrieved successfully.",
            "data": serializer.data
        })


class CompanyWithPerm(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, *args, **kwargs):
        user = request.user
        if not user.company:
            return Response({
                "success": False,
                "message": "User is not assigned to any company.",
                "data": None
            }, status=404)
        company = user.company
        serializer = PermissionListSerializer(company, context={'request': request})
        return Response({
            "success": True,
            "message": "Company retrieved successfully.",
            "data": serializer.data
        })


@method_decorator(csrf_exempt, name='dispatch')
class UserRegistrationView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request, *args, **kwargs):
        user = request.user

        # Only admins (including super-company admins) can register users.
        if not user.is_admin:
            return Response(*standard_response(
                False, 'Only admin users can register new users.',
                status_code=status.HTTP_403_FORBIDDEN
            ))

        # Determine which company the new user belongs to.
        # Super-company admin may supply an explicit company in the payload;
        # regular admin always registers into their own company.
        if is_super_admin(user) or user.is_superuser:
            company = request.data.get('company') or user.company
            if isinstance(company, int):
                try:
                    company = Company.objects.get(id=company)
                except Company.DoesNotExist:
                    return Response(*standard_response(
                        False, 'Target company not found.',
                        status_code=status.HTTP_404_NOT_FOUND
                    ))
        else:
            company = user.company

        serializer = UserRegistrationSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save(company=company)
            return Response(*standard_response(
                True, 'User registered successfully.',
                serializer.data, status.HTTP_201_CREATED
            ))
        return Response(*standard_response(
            False, 'Validation failed.',
            serializer.errors, status.HTTP_400_BAD_REQUEST
        ))


@method_decorator(csrf_exempt, name='dispatch')
class UserLoginView(GenericAPIView):
    permission_classes = [AllowAny]
    serializer_class = UserLoginSerializer

    def post(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.validated_data['user']

        return Response(*standard_response(True, 'User logged in successfully.', {
            'token': get_token_for_user(user),
            'user': {
                'id': user.id,
                'username': user.username,
                'email': user.email,
            },
        }))


@method_decorator(csrf_exempt, name='dispatch')
class UserView(APIView):
    permission_classes = [IsAuthenticated]
    pagination_class = CustomPagination
    serializer_class = MyUserSerializer

    def get(self, request, *args, **kwargs):
        user = request.user
        company_id = request.query_params.get('company_id')

        if user.is_superuser or is_super_admin(user):
            queryset = MyUser.objects.all()
            if company_id:
                queryset = queryset.filter(company_id=company_id)
        elif user.is_admin:
            queryset = MyUser.objects.filter(company=user.company)
        else:
            return Response({
                "success": False,
                "message": "Permission denied.",
            }, status=status.HTTP_403_FORBIDDEN)

        queryset = queryset.order_by('id')
        paginate = request.query_params.get('paginate', 'true').lower() == 'true'

        if paginate:
            paginator = self.pagination_class()
            paginated_queryset = paginator.paginate_queryset(queryset, request, view=self)
            serializer = self.serializer_class(paginated_queryset, many=True)
            return paginator.get_paginated_response(serializer.data)

        serializer = self.serializer_class(queryset, many=True)
        return Response({
            "success": True,
            "message": "User list retrieved successfully without pagination.",
            "data": serializer.data
        })

    def delete(self, request, pk, *args, **kwargs):
        user = request.user

        if not user.is_admin:
            return Response({
                "success": False,
                "message": "Only admin users can delete users."
            }, status=status.HTTP_403_FORBIDDEN)

        try:
            target = MyUser.objects.get(id=pk)
        except MyUser.DoesNotExist:
            return Response({
                "success": False,
                "message": f"User with ID {pk} not found."
            }, status=status.HTTP_404_NOT_FOUND)

        # Regular admin can only delete users within their own company.
        if not (user.is_superuser or is_super_admin(user)):
            if target.company != user.company:
                return Response({
                    "success": False,
                    "message": f"User with ID {pk} does not belong to your company."
                }, status=status.HTTP_403_FORBIDDEN)

        target.delete()
        return Response({
            "success": True,
            "message": f"User with ID {pk} deleted successfully."
        }, status=status.HTTP_200_OK)

    def patch(self, request, pk, *args, **kwargs):
        user = request.user

        if not user.is_admin:
            return Response({
                "success": False,
                "message": "Only admin users can update users."
            }, status=status.HTTP_403_FORBIDDEN)

        try:
            target = MyUser.objects.get(id=pk)
        except MyUser.DoesNotExist:
            return Response({
                "success": False,
                "message": f"User with ID {pk} not found."
            }, status=status.HTTP_404_NOT_FOUND)

        # Regular admin can only update users within their own company.
        if not (user.is_superuser or is_super_admin(user)):
            if target.company != user.company:
                return Response({
                    "success": False,
                    "message": f"User with ID {pk} does not belong to your company."
                }, status=status.HTTP_403_FORBIDDEN)

        serializer = UserRegistrationSerializer(target, data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        serializer.save(company=target.company)

        return Response({
            "success": True,
            "message": f"User with ID {pk} updated successfully.",
            "results": serializer.data
        }, status=status.HTTP_200_OK)


class ServerTime(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        start_time, end_time = Current_saudi_time()
        return Response({"server_time": end_time.isoformat()})
