from tent.models import Tent


def is_super_admin(user):
    """True when the user is an admin of a super company."""
    return (
        user.is_authenticated
        and user.is_admin
        and user.company_id is not None
        and user.company.is_super_company
    )


def get_accessible_tents(user, company_id=None):
    """
    Returns a Tent queryset scoped to what the user is allowed to see.

    Super-admin / superuser  → all tents (optionally filtered by company_id)
    Regular admin            → all tents within their own company
    Staff                    → only their assigned tents within their company
    """
    if user.is_superuser or is_super_admin(user):
        qs = Tent.objects.all()
        if company_id:
            qs = qs.filter(company_id=company_id)
        return qs

    if user.is_admin:
        return Tent.objects.filter(company=user.company)

    assigned_ids = user.assigned_tent.values_list('id', flat=True)
    return Tent.objects.filter(id__in=assigned_ids, company=user.company)
